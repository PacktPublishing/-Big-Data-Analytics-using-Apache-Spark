package main.scala

import org.apache.spark.{SparkConf, SparkContext}

object Main {

  // applications should define a main() method
  def main(args: Array[String]) {
    // I. CREATING A SPARK CONTEXT
    // Spark Properties
    val conf = new SparkConf()
    //* master URL. Here, local[2] represents local mode with two threads. Spark will run locally on this computer, not in distributed mode
    conf.setMaster("local[2]")
    //* Application Name
    conf.setAppName("Word Frequency")
    // passing the SparkContext constructor a conf object which contains information about the application
    val sc = new SparkContext(conf)

    // II. CREATING A RDD : a new RDD from the text of the KJV file in the resources directory:
    val textFile = sc.textFile("src/main/resources/kjv.txt")

    // III. RDD OPERATIONS : RDDs have 1. actions, which return values, and 2. transformations, which return pointers to new RDDs
    // Here, we use transformations to build a dataset of (String, Int) pairs called frequency
    val frequency = textFile.flatMap(line => line.split(" "))
      .map(word => (word, 1))
      .reduceByKey(_ + _)

    frequency.foreach(println)
    System.out.println("Total number of words: " + frequency.count());
    // Save this RDD as a text file
    frequency.saveAsTextFile("/Users/holyspirit/spark/WordCount");
  }
}